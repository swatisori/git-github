package com.example.userdetails;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.telecom.Call;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.ViewTarget;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {

    RecyclerView rv;
    MyAdapter ad;
    LinearLayoutManager m;
    ArrayList al;
    MyTask  mytask;
    public boolean checkInternet(){// this is our  own  method
        //conectivity magager come here
        ConnectivityManager manager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);//it will show some errror
        //please give me ur current  active network here
        NetworkInfo info = manager.getActiveNetworkInfo();
        if(info != null && info.isConnected() == true){
            return true;// internet is  available
        }
        return false;// means there is no internet
    }



    public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder>{


        Context context;
        //constructor
        public MyAdapter( Context context_)
        {

            this.context = context_;
        }


        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View v = getLayoutInflater().inflate(R.layout.row,viewGroup,false);
            ViewHolder vh = new ViewHolder(v);
            return vh;
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
            Details d = (Details) al.get(i);

                Glide.with(context).load(d.getImage_url()).into(viewHolder.im1);
                viewHolder.tv1.setText("Name : " + d.getName());
                viewHolder.tv2.setText("Age : " + d.getAge());




        }

        @Override
        public int getItemCount() {
            return al.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder{
            ImageView im1;
            TextView tv1,tv2;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                im1 = itemView.findViewById(R.id.imageview);
                tv1 = itemView.findViewById(R.id.text1);
                tv2 = itemView.findViewById(R.id.text2);
            }
        }
    }
    public class MyTask extends AsyncTask<String,Void,String>{
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Log.d("userdetail","1");
        }

        @Override
        protected String doInBackground(String... strings) {
            Log.d("userdetail","2"+strings[0]);
            try {
                URL myurl = new URL(strings[0]);
                HttpURLConnection con = (HttpURLConnection) myurl.openConnection();
                InputStream is =  con.getInputStream();
                InputStreamReader ir = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(ir);
                String str = br.readLine();
                StringBuilder sb = new StringBuilder();
                while(str != null){
                    sb.append(str);
                    str = br.readLine();
                }
                  return sb.toString();
            } catch (MalformedURLException e) {
                e.printStackTrace();
                Log.d("jsondata","url error...");
            } catch (IOException e) {
                e.printStackTrace();
                Log.d("jsondata","io error ..");
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
            Log.d("userdetail","3");

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Log.d("userdetail","4");
            Log.d("userdetails","url"+s);

            try {
                JSONObject obj = new JSONObject(s);
                JSONArray  arr1 = obj.getJSONArray("results");
                for(int i = 0;i<arr1.length();i++){
                    JSONObject temp = arr1.getJSONObject(i);
                    JSONObject name = temp.getJSONObject("name");
                    String s1 = name.getString("title");
                   String s2 = name.getString("first");
                    String s3 = name.getString("last");
                    JSONObject dob  = temp.getJSONObject("dob");
                    String age = dob.getString("age");
                    JSONObject pic = temp.getJSONObject("picture");
                    String image = pic.getString("large");
                    String str = s1+"."+" "+s2+" "+s3;
                    Log.d("userdetails","url"+image);
                    Details user = new Details(image,str,age);
                    al.add(user);

                    ad.notifyDataSetChanged();
                }
            } catch (JSONException e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "jason exception", Toast.LENGTH_SHORT).show();

            }


        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rv = findViewById(R.id.recycler);
        al = new ArrayList<String>();
        ad = new MyAdapter(this);
        m = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        rv.setAdapter(ad);
        rv.setLayoutManager(m);
        if (checkInternet() == true) {
            Toast.makeText(this, "wait .. page is loading ..", Toast.LENGTH_SHORT).show();// we cant show blank page so we write toast until it loads
            mytask = new MyTask();
            mytask.execute("https://raw.githubusercontent.com/iranjith4/radius-intern-mobile/master/users.json");
        }
        else{
            Toast.makeText(this, "please turn on the internet", Toast.LENGTH_SHORT).show();
        }

    }

}
